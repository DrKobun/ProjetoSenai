package br.com.eventos;

public interface Ingresso 
{
	public String consultarIngressos();
	public double adicionarSaldo(double valor);
}
