package br.com.eventos;

public class Atributo implements Ingresso
{
	private String nome;
	private String idade;
	private String cpf;
	private String email;
	private String telefone;
	private String genero;
	private double saldo;
	private int ingressoAngra;
	private int ingressoDragonForce;
	private int ingressoJoelma;
	
	public int compraJoelma() 
	{
		return ingressoJoelma++;
	}
	
	public int compraAngra() 
	{
		return ingressoAngra++;
	}
	
	public int compraDragonForce() 
	{
		return ingressoDragonForce++;
	} 
	
	public String dadosUsuario() 
	{
		return "Nome: " + this.nome	+		
			   "\nIdade: " + this.idade + 
			   "\nCPF: " + this.cpf + 
			   "\nE-mail: " + this.email + 
			   "\nTelefone: " + this.telefone + 
			   "\nG�nero: " + this.genero;
	}
	
	public double descontarValor(double subtrair)
	{
		return saldo -= subtrair;
	}
	
	public double consultarCarteira() 
	{
		return this.saldo;
	}
	
	@Override
	public double adicionarSaldo(double valor) 
	{
		return this.saldo += valor;
	}
	@Override
	public String consultarIngressos() 
	{
		double angra = ingressoAngra;
		double dragonForce = ingressoDragonForce;
		double joelma = ingressoJoelma;

		return "Ingressos comprados:\n" + "Angra: " + angra + "\nDragonForce: " + dragonForce + "\nJoelma: " + joelma;
	}
	
	public String getNome()
	{
		return nome;
	}
	
	public void setNome(String nome)
	{
		this.nome = nome;
	}
	
	public String getIdade() 
	{
		return idade;
	}
	
	public void setIdade(String idade) 
	{
		this.idade = idade;
	}
	
	public String getCpf()
	{
		return cpf;
	}
	
	public void setCpf(String cpf) 
	{
		this.cpf = cpf;
	}
	
	public String getEmail() 
	{
		return email;
	}
	
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	public String getTelefone()
	{
		return telefone;
	}
	
	public void setTelefone(String telefone)
	{
		this.telefone = telefone;
	}
	
	public String getGenero(
			) {
		return genero;
	}
	
	public void setGenero(String genero) 
	{
		this.genero = genero;
	}
	
	public double getSaldo()
	{
		return saldo;
	}
	
	public void setSaldo(double saldo) 
	{
		this.saldo = saldo;
	}

}
