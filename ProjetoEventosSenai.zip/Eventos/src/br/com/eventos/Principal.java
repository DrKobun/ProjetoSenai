package br.com.eventos;

import javax.swing.JOptionPane;

public class Principal
{
	public static void main(String[] args)
	{
		Atributo usuario = new Atributo();
		
		
		
		JOptionPane.showMessageDialog(null, "Servi�o de eventos (pressione 'ok' para continuar)");
		usuario.setNome(JOptionPane.showInputDialog("Insira seus dados: \nNome:"));
		usuario.setIdade(JOptionPane.showInputDialog("Insira sua Idade: \nIdade:"));
		usuario.setCpf(JOptionPane.showInputDialog("Insira seu CPF: \nCPF:"));
		usuario.setEmail(JOptionPane.showInputDialog("Insira seu E-mail: \nE-mail:"));
		usuario.setGenero(JOptionPane.showInputDialog("Insira seu G�nero: \nG�nero:"));
		usuario.setTelefone(JOptionPane.showInputDialog("Informe seu telefone para contato: \nTelefone:"));
		
		Object[] opcao = {"Escolher evento", "Consultar saldo", "Depositar dinheiro", "Verificar dados", "Consultar ingressos","Sair"};
		Object selecionarOpcao;
		
		Object[] evento = {"Angra (R$ 200)", "DragonForce (R$ 140)", "Joelma (R$ 340)"};
		Object eventoOpcao;
		
		do 
		{
			selecionarOpcao = JOptionPane.showInputDialog(null, "Escolha uma op��o:", "Continuar", JOptionPane.INFORMATION_MESSAGE, null, opcao, opcao[0]);
		
			if(selecionarOpcao == "Depositar dinheiro") 
			{
				String valor;
				
				valor = JOptionPane.showInputDialog("Valor a depositar");
				
				usuario.adicionarSaldo(Double.parseDouble(valor));
				JOptionPane.showMessageDialog(null, "Valor depositado: " + valor + " R$.");
			}
			if(selecionarOpcao == "Consultar saldo") 
			{
				JOptionPane.showMessageDialog(null, "Valor na carteira: " + usuario.consultarCarteira() + " R$.");
			}
			if(selecionarOpcao == "Escolher evento") 
			{
				eventoOpcao = JOptionPane.showInputDialog(null, "Escolha uma op��o", "Continuar", JOptionPane.INFORMATION_MESSAGE, null, evento, evento[0]);
			
				if(eventoOpcao == "Angra (R$ 200)") 
				{
					JOptionPane.showMessageDialog(null, "Evento escolhido: Angra \nValor do ingresso: 200R$");
					if(usuario.getSaldo() < 200) 
					{
						JOptionPane.showMessageDialog(null, "Saldo insuficiente!\nVoltando ao menu principal");
					} else 
					{
						usuario.descontarValor(200);
						JOptionPane.showMessageDialog(null, "Ingresso para Angra comprado com sucesso!");
						usuario.compraAngra();
					}
				}
				if(eventoOpcao == "DragonForce (R$ 140)") 
				{
					JOptionPane.showMessageDialog(null, "Evento escolhido: DragonForce \nValor do ingresso: 140R$");
					if(usuario.getSaldo() < 140) 
					{
						JOptionPane.showMessageDialog(null, "Saldo insuficiente!\nVoltando ao menu principal");
					} else 
					{
						usuario.descontarValor(140);
						JOptionPane.showMessageDialog(null, "Ingresso para DragonForce comprado com sucesso!");
						usuario.compraDragonForce();
					}
				}
				if(eventoOpcao == "Joelma (R$ 340)") 
				{
					JOptionPane.showMessageDialog(null, "Evento escolhido: Joelma \nValor do ingresso: 340R$");
					if(usuario.getSaldo() < 340) 
					{
						JOptionPane.showMessageDialog(null, "Saldo insuficiente! \nVoltando ao menu principal");
					} else
					{
						usuario.descontarValor(340);
						JOptionPane.showMessageDialog(null, "Ingresso para Joelma comprado com sucesso!");
						usuario.compraJoelma();
					}	
				}
			}
			if(selecionarOpcao == "Verificar dados") 
			{
				JOptionPane.showMessageDialog(null, usuario.dadosUsuario());
			}
		
			if(selecionarOpcao == "Consultar ingressos") 
			{
				JOptionPane.showMessageDialog(null, usuario.consultarIngressos());
			}
	
		}while(selecionarOpcao != "Sair");	
	}
}
